/* 
 * Author: Jacob Velasquez
 * Date: January 7, 2019, 7:24 PM
 * Purpose: First Program Hello World,
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<endl;
    cout<<"   Hello World!  "<<endl;
    cout<<endl;
    
    //Exit
    return 0;
}